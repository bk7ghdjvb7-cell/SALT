package org.salt.savannah;

import android.app.Activity;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.Arrays;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import org.salt.savannah.security.FaceBlur;
import org.salt.savannah.security.KeyAttemptPolicy;
import org.salt.savannah.security.LoginGuard;
import org.salt.savannah.security.PostLimiter;
import org.salt.savannah.security.SaltCrypto;

/** Native SALT controls. Group and private messages stay ciphertext without the chat key. */
public final class MainActivity extends Activity {
    public static final String CONTENT_SECURITY_POLICY =
        "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; "
            + "img-src 'self' blob: data: https://images.unsplash.com; font-src 'self'; connect-src 'self'; "
            + "form-action 'self'; base-uri 'self'; object-src 'none'; frame-ancestors 'self'";

    private final LoginGuard loginGuard = new LoginGuard();
    private final PostLimiter postLimiter = new PostLimiter();
    private final KeyAttemptPolicy keyPolicy = new KeyAttemptPolicy();
    private final List<String> members = new ArrayList<>();
    private byte[] publicPhoto;
    private String wrappedGroupKey;
    private final byte[] groupSalt = new byte[] {4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4};
    private TextView status;
    private CheckBox consentReview;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        members.add("creator");
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        EditText email = new EditText(this);
        email.setHint("Email");
        EditText password = new EditText(this);
        password.setHint("Password");
        EditText post = new EditText(this);
        post.setHint("Public post");
        EditText chatKey = new EditText(this);
        chatKey.setHint("Group encryption key");
        status = new TextView(this);
        status.setText("Group chat is locked until the creator's key is entered.");
        Button signIn = new Button(this);
        signIn.setText("Sign in");
        signIn.setOnClickListener(view -> attemptLogin(email.getText().toString(), password.getText().toString()));
        Button publish = new Button(this);
        publish.setText("Publish public post");
        publish.setOnClickListener(view -> publishPost(post.getText().toString()));
        consentReview = new CheckBox(this);
        consentReview.setText("Send an encrypted copy to admin for consent review");
        Button photo = new Button(this);
        photo.setText("Choose photo");
        photo.setOnClickListener(view -> startActivityForResult(new Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), 7));
        Button unlock = new Button(this);
        unlock.setText("Unlock group chat");
        unlock.setOnClickListener(view -> unlockChat(chatKey.getText().toString()));
        layout.addView(email);
        layout.addView(password);
        layout.addView(signIn);
        layout.addView(post);
        layout.addView(publish);
        layout.addView(consentReview);
        layout.addView(photo);
        layout.addView(chatKey);
        layout.addView(unlock);
        layout.addView(status);
        setContentView(layout);
    }

    private void attemptLogin(String email, String password) {
        long now = System.currentTimeMillis();
        try {
            loginGuard.begin(email, now);
        } catch (SecurityException ex) {
            status.setText("Too many sign-in attempts. Wait 15 minutes.");
            return;
        }
        boolean ok = email.contains("@") && password.length() >= 12;
        loginGuard.record(email, ok, now);
        status.setText(ok ? "Signed in." : "Sign-in failed.");
    }

    private void publishPost(String text) {
        try {
            postLimiter.consume("member", System.currentTimeMillis());
        } catch (SecurityException ex) {
            status.setText("Public posts are limited to 3 per hour.");
            return;
        }
        if (publicPhoto == null && text.trim().isEmpty()) {
            status.setText("Add text or a blurred photo.");
            return;
        }
        status.setText("Post kept locally. Live posts go through the moderated server endpoint.");
    }

    private void unlockChat(String passphrase) {
        if (passphrase.length() < 12) {
            status.setText("Use a key of at least 12 characters.");
            return;
        }
        byte[] derived = SaltCrypto.chatKey(passphrase, groupSalt);
        if (wrappedGroupKey == null) {
            wrappedGroupKey = SaltCrypto.seal(new byte[] {1, 2, 3, 4}, derived);
            keyPolicy.wrappedKey = wrappedGroupKey;
            status.setText("Group created. Messages require this key.");
            return;
        }
        boolean matched;
        try {
            SaltCrypto.open(wrappedGroupKey, derived);
            matched = true;
        } catch (SecurityException ex) {
            matched = false;
        }
        KeyAttemptPolicy.Result result = keyPolicy.attempt(matched, System.currentTimeMillis(), "creator", members::remove);
        if (result == KeyAttemptPolicy.Result.BLOCKED) {
            wrappedGroupKey = "";
        }
        status.setText("Key result: " + result);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != 7 || resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try (InputStream input = getContentResolver().openInputStream(uri)) {
            if (input == null) throw new SecurityException("image rejected");
            ByteArrayOutputStream raw = new ByteArrayOutputStream();
            byte[] chunk = new byte[8192];
            int read;
            while ((read = input.read(chunk)) >= 0) raw.write(chunk, 0, read);
            byte[] original = raw.toByteArray();
            if (BitmapFactory.decodeByteArray(original, 0, original.length) == null) {
                throw new SecurityException("image rejected");
            }
            boolean review = consentReview.isChecked();
            FaceBlur.Prepared prepared = FaceBlur.prepare(this, original, review);
            Arrays.fill(original, (byte) 0);
            publicPhoto = prepared.publicJpeg;
            status.setText(prepared.facesFound
                ? "Faces blurred before upload. Encrypted consent review " + prepared.reviewId
                : "No face found. Only the scanned image is kept.");
        } catch (Exception ex) {
            publicPhoto = null;
            status.setText("The photo was not uploaded because faces could not be scanned.");
        }
    }
}
